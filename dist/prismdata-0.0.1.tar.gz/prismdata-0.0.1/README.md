# prismdata

[![PyPI - Version](https://img.shields.io/pypi/v/prismdata.svg)](https://pypi.org/project/prismdata)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install prismdata
```

## License

`prismdata` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
